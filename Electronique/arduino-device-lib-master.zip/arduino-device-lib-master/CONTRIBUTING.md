## Contributing

We'd ❤️ to welcome your contribution. Please make sure your changes include:

1.  Examples: [examples](examples)
2.  Syntax highlighting: [keywords.txt](keywords.txt)
3.  Documentation: [docs](docs)
4.  Tests: [test](test)
5.  Verification of the examples and tests: [.travis.yml](.travis.yml)
